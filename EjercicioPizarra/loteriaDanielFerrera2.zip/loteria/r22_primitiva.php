<!DOCTYPE HTML>
<html>
<head>
	<meta charset="utf-8">
	<title>Primitiva HTML</title>
</head>
<body>
	<img src="primitiva.jpg">
	<form action="r22_funciones.php" method="post">
		<p>Fecha del sorteo <input type='date' name='fechasorteo' size=15><br>
			<p>Recaudación Sorteo <input type='text' name='recaudacion' size=10><br>
				<p>Pulsa para generar combinación ganadora:
					<input type="submit" value="Combinacion" name="combinacion"></p>
				</form>
			</body>
			</html>
