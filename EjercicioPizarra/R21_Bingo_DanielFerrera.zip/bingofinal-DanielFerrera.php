<HTML>
  <HEAD><TITLE> Reto 1 - BINGO</TITLE></HEAD>
  <BODY style='background-color:#A272C4'>
    <?php
    echo "<center>";
    echo "<h3>Reto 1 - BINGO - Daniel Ferrera</h3>";
    echo "<table border='10' bgcolor='grey'> <caption><h1> Bolas </h1></caption> <tr>";
    //bolas del bingo
    echo bolas();
    function bolas(){
    $fila=0;
    for ($i=1; $i <= 60 ; $i++) {
      if (($fila%10==0)) {
        echo "</tr><tr><td><img src=bolas/$i.png width=60px height=60px bgcolor='grey' /></td>";
      }else{
        echo "<td><img src=bolas/$i.png width=60px height=60px bgcolor='grey' /></td>";
      }
      $fila++;
    }
    echo "</table>";
}
    //datos necesarios
    //AQUI SE INTRODUCEN LAS PERSONAS Y LOS CARTONES
    //CON LOS QUE SE QUIERE JUGAR AL BINGO
    $personasajugar=4;
    $cartonesporpersona=3;

    //prueba
    // $prueba=array(0,0,0);
    // $prueba1=array(1,1,1);
    // $prueba2=array(2,2,2);
    // $contiene=array($prueba,$prueba1,$prueba2);
    // var_dump($contiene);

    // //creo los contadores para meter 15 bolas en todos los cartones, tiene que estar fuera
    // $multiplicado=$personasajugar*$cartonesporpersona;
    // for ($i=0; $i <$multiplicado ; $i++) {
    //   $contador[$multiplicado]=0;
    // }
    echo jugadores($personasajugar);
    function jugadores($personasajugar){
    //creo los jugadores
    for ($i=1; $i <($personasajugar+1) ; $i++) {
      // echo "<h1>Se ha creado el Jugador $i</h1>";
    ${"jugador".$i}=array();
    }
  }
    //cartones
    echo cartones($personasajugar,$cartonesporpersona);
    function cartones($personasajugar,$cartonesporpersona){
    $codigo=0;
    for ($i=0; $i <($cartonesporpersona*$personasajugar) ; $i++) {
      // echo "<h1>Se ha creado el Jugador $i</h1>";
      ${"carton".$i}=array();
      $contador1=0;
      while ($contador1<15) {
        $num = rand(1,60);
        if (!(in_array($num,${"carton".$i}))){
          array_push(${"carton".$i},$num);
          $contador1++;
        }
      }
      sort(${"carton".$i});
      if ($i%$cartonesporpersona==0) {
        $codigo++;
        echo "<h2>Jugador $codigo</h2>";
      }
      echo "<h2>Carton $i</h2>";
      echo "</br>";
      echo "<table border='10' bgcolor='grey'><tr>";
      $cartonjugador=${"carton".$i};
      for ($k=0; $k< sizeof($cartonjugador) ; $k++) {
        echo "<td><img src = bolas/$cartonjugador[$k].png width=55px height=55px/> </td>";
      }
      echo "</tr></table>";
      echo "</br>";
    }

    // for ($i=1; $i <($personasajugar+1) ; $i++) {
    //   for ($j=0; $j <$cartonesporpersona ; $j++) {
    //   //introduzco el carton al jugador que le corresponde
    //   array_push(${"jugador".$i},${"carton".$j});
    // }
    // }
    //echo "<h2>Cartones del Jugador $i</h2>";
    //var_dump($jugador[$i]);

    // for ($i=1; $i <($personasajugar+1) ; $i++) {
    //   echo "</br>";
    //   echo "<h1>JUGADOR $i</h1>";
    //   echo "</br>";
    //   echo cartones(${"jugador".$i},$cartonesporpersona);
    // }
    //
    // function cartones($jugador,$cartonesporpersona){
    //   for ($i=0; $i <$cartonesporpersona ; $i++) {
    //     echo "<h2>Carton $i</h2>";
    //     echo "</br>";
    //     echo "<table border='10' bgcolor='grey'><tr>";
    //     $cartonjugador=$jugador[$i];
    //     for ($k=0; $k< sizeof($cartonjugador) ; $k++) {
    //       echo "<td><img src = bolas/$cartonjugador[$k].png width=55px height=55px/> </td>";
    //     }
    //     echo "</tr></table>";
    //     echo "</br>";
    //   }
    // }


    //${"nombrevariable".$i}

    //creo el carton 1
    // $carton1 = array();
    // $contador = 0;
    // while ($contador<15) {
    //   $generador = rand(1,60);
    //   if (!in_array($generador,$carton1)) {
    //     array_push($carton1,$generador);
    //     $contador++;
    //   }
    // }
    //
    // //muestro el carton 1
    // echo "<h1>CARTON 1</h1>";
    // for ($i=0; $i <sizeof($carton1) ; $i++) {
    //   echo "$carton1[$i] - ";
    // }
    //
    // echo "</br>";
    //
    // for ($i=0; $i <sizeof($carton1) ; $i++) {
    //     echo "<td><img src=bolas/$carton1[$i].png /></td>";
    // }

    // $comprobar=array();
    // $contador1=0;
    //
    // echo "<h1>EMPIEZA EL CANTE</h1>";
    // while ($contador1<15) {
    //   $num=rand(1,60);
    //   if (!(in_array($num,$comprobar))) {
    //     array_push($comprobar,$num);
    //     echo "El: $num - ";
    //   for ($i=0; $i <15 ; $i++) {
    //     if ($carton1[$i]==$num) {
    //       $contador1++;
    //       echo " Numero encontrado ";
    //     }
    //   }
    // }
    // }
    // echo "BINGOOOOOOOOOOOOOOOO";

    //hago un array de contadores y luego miro con un in_array si hay alguno que tiene 15 para sacar el ganador
    //cont00,cont01,cont
    $contadores=array();
    for ($i=0; $i <($personasajugar*$cartonesporpersona) ; $i++) {
        ${"cont".$i}=0;
        array_push($contadores,${"cont".$i});
      }
    //prueba de que van los contadpres van bien
    //var_dump($contadores);

    //PARA COMPROBAR QUE HA GANADO ALGUIEN HARE IN_ARRAY(15) SERA EL GANADOR
    //creo el bombo con numeros aleatorios que no se repiten
    //reviso que en cada carton este ese numero o no
    $bombo=array();
    $bombocont=0;
    $ganador=false;
    //creo el carton ganador para meter los numeros ahi
    // $cartonganador=array();
    $parar1=false;
    $parar2=false;
    $parar3=false;
    $parar4=false;

    echo "<h1>Van saliendo los numeros...</h1>";

    //JUGADORES SON: $jugador1,$jugador2,$jugador3,$jugador4
    //CARTONES SON: $carton0,$carton1,$carton2,$carton3,$carton4...
    //CONTADORES SON: $cont0,$cont1,$cont2,$cont3,$cont4,$cont5,$cont6...

    while ($bombocont <60 && $ganador==false) {
         $num=rand(1,60);
         if (!(in_array($num,$bombo))) {
           array_push($bombo,$num);
           $bombocont++;
           //echo "El: $num - ";
           echo "<img src = bolas/$num.png width=55px height=55px/>";
           //recorro todos los cartones que hay creados y rellenos
             for ($i=0; $i <($cartonesporpersona*$personasajugar); $i++) {
               //recorro todas las posiciones del carton
               //for ($e=0; $e <15 ; $e++) {
               if(in_array($num,${"carton".$i})){
                 ${"cont".$i}++;
                 // echo ${"cont".$i} . " || ";
                 if ( ${"cont".$i}==15) {
                   $ganador=true;
                   echo "<h3>Bingo en el Carton $i</h3>";
                   if (($cont0==15 || $cont1==15 || $cont2==15) && $parar1==false) {
                     echo "<h3>Ha ganado el Jugador 1</h3>";
                     $parar1=true;
                   }
                   if (($cont3==15 || $cont4==15 || $cont5==15) && $parar2==false) {
                     echo "<h3>Ha ganado el Jugador 2</h3>";
                     $parar2=true;
                   }
                   if (($cont6==15 || $cont7==15 || $cont8==15) && $parar3==false) {
                     echo "<h3>Ha ganado el Jugador 3</h3>";
                     $parar3=true;
                   }
                   if (($cont9==15 || $cont10==15 || $cont11==15) && $parar4==false) {
                     echo "<h3>Ha ganado el Jugador 4</h3>";
                     $parar4=true;
                   }
                 }// del if
               }// del if
             }//del for
         }//del primer if
       }// del while




    //   for ($i=1; $i <$personasajugar ; $i++) {
    //
    //     do{//comprobamos que la bola no haya salido antes
    //   $num_aleatorio=rand(1,60);//sacamos la bola
    //
    // }while(in_array($num_aleatorio,$cartonganador)==true);
    //      for ($j=1; $j <5 ; $j++) {
    //
    //   if(in_array($num_aleatorio,${"jugador".$j}[0])){
    //     ${"cont".$i.$j}[0]++;
    //   }
    //   if(in_array($num_aleatorio,${"jugador".$j}[1])){
    //     ${"cont".$i.$j}[1]++;
    //   }
    //   if(in_array($num_aleatorio,${"jugador".$j}[2])){
    //     ${"cont".$i.$j}[2]++;
    //   }
    //   if (in_array(15,${"cont".$i.$j})) {
    //   $ganador="Jugador $j";
    //
    //   }
    //      }
    //          array_push($cartonganador,$num_aleatorio);
    //    }
    //
    //
    //
    //   while ($bombocont <60 || $ganador=false) {
    //     $num=rand(1,60);
    //     if (!(in_array($num,$bombo))) {
    //       array_push($bombo,$num);
    //       $bombocont++;
    //       echo "El: $num - ";
    //     }
    //   }
    //
    // while(in_array($num,$cartonganador));
    //        for ($j=1; $j <5 ; $j++) {
    //
    //     if(in_array($num_aleatorio,${"jug".$j}[0])){
    //       ${"contjug".$j}[0]++;
    //     }
    //     if(in_array($num_aleatorio,${"jug".$j}[1])){
    //       ${"contjug".$j}[1]++;
    //     }
    //     if(in_array($num_aleatorio,${"jug".$j}[2])){
    //       ${"contjug".$j}[2]++;
    //     }
    //     if (in_array(15,${"contjug".$j})) {
    //     $ganador="Jugador $j";
    //
    //     }
    //        }
    //            array_push($cartonganador,$num_aleatorio);
    //      }
}

    echo "</center>";
    ?>
  </BODY>
</HTML>
