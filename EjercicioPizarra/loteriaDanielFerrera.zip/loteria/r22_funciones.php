<?php

$fechasorteo=$_POST['fechasorteo'];
$recaudacion=$_POST['recaudacion'];
echo "<h1>RESULTADOS SORTEO PRIMITIVA</h1>";
echo "La fecha del sorteo es: <b>$fechasorteo</b></br>";
echo "La recaudacion realizada es de: <b>$recaudacion</b></br>";

echo "<h1>COMBINACION GANADORA</h1>";
$combinacionganador=numeroganador();
//recorremos el numero sin mas
pintar($combinacionganador);
$linea1array=pintarfichero($combinacionganador);
pintar($linea1array);
ganadorreintegro($combinacionganador,$linea1array);
ganador3($combinacionganador,$linea1array);

//CREACION DE LA COMBINACION GANADORA DE LA PRIMITIVA
function numeroganador(){
  //hago un array para meter 7 numeros, 6 y 1- complementario
  $combinacionganador=array();
  $i=0;
  while (count($combinacionganador)<7){
    //7 numeros entre el 1 y 49 que no se puedan repetir
    $num=rand(1,49);
    if (! (in_array($num,$combinacionganador)))
    $combinacionganador[$i++]=$num;
  }
  //añadimos el reintegro
  $num=rand(0,9);
  array_push($combinacionganador,$num);
  return $combinacionganador;
}//numero ganador

function pintar($combinacionganador){
  // echo "NUMERO: ";
  // foreach ($combinacionganador as $valor) {
  //   echo "$valor ";
  // }
  echo "</br>";
  $tamaño=count($combinacionganador);
  for ($i=0; $i <$tamaño-1 ; $i++) {
    echo "<img src=imagesbolas/$combinacionganador[$i].png width=70px height=70px/>";
  }
  for ($i=7; $i <$tamaño ; $i++) {
    echo "<img src=imagesbolas/rbola$combinacionganador[$i].png width=70px height=70px/>";
  }
  echo "</br></br>";
}//pintar


function pintarfichero($combinacionganador){
  //abrimos fichero con resultados
  //formato
  //1 numero de usuario
  // del 2 al 8, numeros,
  //9, reintegro
  $fichero=file("prueba.txt");
  // recorremos el array y lo mostramos por pantalla
  $array=array();
  foreach($fichero as $linea=>$texto) {
    if ($linea>=1) {
      $partes=explode("-",$texto);
      echo "JUGADOR $linea:  $partes[0]";
    }
    echo "</br>";
    $partes=explode("-",$texto);
    $tamaño=sizeof($partes);
    if ($linea>=1) {
      for ($i=1; $i <$tamaño ; $i++) {
        array_push($array,$partes[$i]);
      }
      // var_dump($array);
    }
  }
  for ($i=0; $i <$tamaño-1 ; $i++) {
    echo "$array[$i] ";
  }
  echo "</br>";
  return $array;
}

function ganadorreintegro($combinacionganador,$linea1array){
  //meto las dos combinaciones para comprobarlas
  $usuariosreintegro=0;
  // var_dump($combinacionganador);
  // var_dump($linea1array);
  $tamaño=count($combinacionganador);
  for ($i=$tamaño-1; $i <$tamaño ; $i++) {
    if ($combinacionganador[$i]==$linea1array[$i]) {
      echo "Ganador del reintegro: $combinacionganador[$i]---$linea1array[$i]</br>";
      $usuariosreintegro++;
    }
  }
}

function ganador3($combinacionganador,$linea1array){
  $tamaño=count($combinacionganador);
  $cont3=0;
  //hay algo mal que no va
 for ($i=0; $i <$tamaño-1 ; $i++) {
   if ($combinacionganador[$i]==$linea1array[$i]) {
     $cont3++;
     echo "NUMERO IGUAL: $combinacionganador[$i] - $linea1array[$i]</br>";
   }
 }
 if ($cont3==1) {
   echo "HAY UN NUMERO IGUAL</br></br>";
 }

}



?>
