<?php
$array1=array(1,2,3,4,5,6,7);
$tamaño=sizeof($array1);
var_dump($array1);
$array2=array(1,2,4);
var_dump($array2);
$tamaño2=sizeof($array2);
$cont=0;
echo "vamos a mirar cuales son iguales:</br>";
for ($i=0; $i <$tamaño ; $i++) {
  for ($k=0; $k <$tamaño2 ; $k++) {
    if ($array1[$i]==$array2[$k]) {
      $cont++;
    }
  }
}
  echo "$cont";
 ?>
