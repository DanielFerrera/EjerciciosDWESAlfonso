<?php
function inicio(){
  $fechasorteo=$_POST['fechasorteo'];
  $recaudacion=$_POST['recaudacion'];
  echo "<h1>RESULTADOS SORTEO PRIMITIVA</h1>";
  echo "La fecha del sorteo es: <b>$fechasorteo</b></br>";
  echo "La recaudacion realizada es de: <b>$recaudacion</b></br>";
  echo "<h1>COMBINACION GANADORA</h1>";
  // $combinacionganador=array(1,2,3,4,5,6,7,8);
  $combinacionganador=numeroganador();
  //recorremos el numero sin mas
  $totalapuestas=0;
  pintar($combinacionganador);
  pintarsimple($recaudacion,$fechasorteo,$combinacionganador,$totalapuestas);
  // resultados($recaudacion,$totalapuestas,$fechasorteo);
}

//CREACION DE LA COMBINACION GANADORA DE LA PRIMITIVA
function numeroganador(){
  //hago un array para meter 7 numeros, 6 y 1- complementario
  $combinacionganador=array();
  $i=0;
  while (count($combinacionganador)<7){
    //7 numeros entre el 1 y 49 que no se puedan repetir
    $num=rand(1,49);
    if (! (in_array($num,$combinacionganador)))
    $combinacionganador[$i++]=$num;
  }
  //añadimos el reintegro
  $num=rand(0,9);
  array_push($combinacionganador,$num);
  return $combinacionganador;
}//numero ganador

function pintar($combinacionganador){
  echo "</br>";
  $tamaño=count($combinacionganador);
  for ($i=0; $i <$tamaño-1 ; $i++) {
    echo "<img src=imagesbolas/$combinacionganador[$i].png width=70px height=70px/>";
  }
  for ($i=7; $i <$tamaño ; $i++) {
    echo "<img src=imagesbolas/rbola$combinacionganador[$i].png width=70px height=70px/>";
  }
  echo "</br></br>";
}//pintar

function pintarsimple($recaudacion,$fechasorteo,$combinacionganador,$totalapuestas){
  $fichero=file("r22_primitiva.txt");
  $arraypuntuaciones=array(0,0,0,0,0,0,0,0,0);
    foreach($fichero as $linea=>$texto) {
    if ($linea>=1) {
      //esta era la linea que no me cogia
      //cuidado con esto de arriba
      global $totalapuestas;
      $totalapuestas++;
      // echo "Linea: ",$linea," Texto: ",$texto,"<br>";
      // var_dump(${"array".$linea});
      $arraypuntuaciones=comprobaciones($combinacionganador,$arraypuntuaciones,$texto);
    }
  }
   // var_dump($arraypuntuaciones);
   echo "Total apuestas: <b>".$totalapuestas."</b></br>";
   echo "Acertantes 6 números: <b>".$arraypuntuaciones[0]."</b></br>";
   echo "Acertantes 5 números + Complementario: <b>".$arraypuntuaciones[1]."</b></br>";
   echo "Acertantes 5 números: <b>".$arraypuntuaciones[2]."</b></br>";
   echo "Acertantes 4 números: <b>".$arraypuntuaciones[3]."</b></br>";
   echo "Acertantes 3 números: <b>".$arraypuntuaciones[4]."</b></br>";
   echo "Acertantes Reintegros: <b>".$arraypuntuaciones[8]."</b></br>";
   echo "Sin premio 2 números: <b>".$arraypuntuaciones[5]."</b></br>";
   echo "Sin premio 1 números: <b>".$arraypuntuaciones[6]."</b></br>";
   echo "Sin premio 0 números: <b>".$arraypuntuaciones[7]."</b></br>";

   resultados($recaudacion,$totalapuestas,$fechasorteo,$arraypuntuaciones);
}

function comprobaciones($combinacionganador,$arraypuntuaciones,$linea1array){
  $tamaño=count($combinacionganador);
  // $tamaño2=count($linea1array);
  //6,5C,5,4,3,2,1,0,R
  $linea=explode("-",$linea1array);
  $contadorgeneral=0;
  // echo "reintegros: ".$usuariosreintegro;
  //3 y 4
  for ($i=0; $i <$tamaño-2 ; $i++) {
      if ($combinacionganador[$i]==$linea[$i+1]) {
        $contadorgeneral++;
    }
  }

  if ($contadorgeneral==6) {
    $arraypuntuaciones[0]++;
  }

  //complementario
  if ($contadorgeneral==5) {
    for ($i=0; $i <$tamaño-1; $i++) {
      if ($combinacionganador[$i]==$linea[6]) {
        $arraypuntuaciones[2]++;
      }
    }
    $arraypuntuaciones[1]++;
  }

  if ($contadorgeneral==4) {
  $arraypuntuaciones[3]++;
  }

  if ($contadorgeneral==3) {
    $arraypuntuaciones[4]++;
  }

  if ($contadorgeneral==2) {
    $arraypuntuaciones[5]++;
  }

  if ($contadorgeneral==1) {
    $arraypuntuaciones[6]++;
  }
  if ($contadorgeneral==0) {
    $arraypuntuaciones[7]++;
  }

  for ($i=0; $i <$tamaño ; $i++) {
    //reintegro
    if ($i==7 && ($combinacionganador[$i]==$linea[$i+1])) {
      $arraypuntuaciones[8]++;
    }
  }
  return $arraypuntuaciones;
}

function resultados($recaudacion,$totalapuestas,$fechasorteo,$arraypuntuaciones){
$dineroobtenido=$recaudacion*$totalapuestas;
$recaudaciontotal=$dineroobtenido*0.8;

$dentrofichero=fopen("premiosorteo$fechasorteo.txt","w");
//6 aciertos
$premio6=$recaudaciontotal*0.4*$arraypuntuaciones[0];
$premio5=$recaudaciontotal*0.3*$arraypuntuaciones[1];
$premio4=$recaudaciontotal*0.15*$arraypuntuaciones[2];
$premio3=$recaudaciontotal*0.5*$arraypuntuaciones[3];
$premio2=$recaudaciontotal*0.8*$arraypuntuaciones[4];
$premio1=$recaudaciontotal*0.2*$arraypuntuaciones[8];

fwrite($dentrofichero,"C6#$premio6\n");
fwrite($dentrofichero,"C5#$premio5\n");
fwrite($dentrofichero,"C5#$premio4\n");
fwrite($dentrofichero,"C4#$premio3\n");
fwrite($dentrofichero,"C3#$premio2\n");
fwrite($dentrofichero,"CR#$premio1\n");

fclose($dentrofichero);
}

?>
