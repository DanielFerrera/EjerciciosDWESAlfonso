<?php
echo "Mostrar pagos e importes realizados entre dos fechas de un cliente";
 ?>
