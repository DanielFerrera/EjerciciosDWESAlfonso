<?php
echo "Pagina para consultar el stock de un producto";
 ?>
