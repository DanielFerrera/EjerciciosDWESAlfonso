<!-- Código realizado por Daniel Ferrera -->
<!-- Fichero de funciones  -->
<?php
//Funcionalidad: Eliminar caracteres extraños, espacios y devolverlos para poder tratarlos sin problemas
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

//Funcionalidad: Revision de los parametros introducidos por teclado
function revisarparametros($nombre,$contra){
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = test_input($_POST["nombre"]);
    $contra = test_input($_POST["contra"]);
  }
}

//Funcionalidad: Crear la sesion a la base de datos
function crearconexion($servername, $username, $password, $dbname){
  try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
  catch(PDOException $e)
  {
    echo "Conexion fallida: " . $e->getMessage();
  }
  return $conn;
}

//Funcionalidad: Validar el usuario y contraseña y devuelve el nombre de usuario
function contra($nombre,$contra,$conn){
  echo "</br>";
  $customername="0";
  try {
    $stmt1 = $conn->prepare("SELECT customerName FROM customers WHERE customerNumber='$nombre' and contactLastName='$contra'");
    $stmt1->execute();
    $result1 = $stmt1->setFetchMode(PDO::FETCH_ASSOC);
    foreach($stmt1->fetchAll() as $row) {
      $customername=$row["customerName"];
    }
  }//try
  catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
  }
  //Si lo devuelve completo es por que concuerda, sino lo devuelve vacío
  return $customername;
}



?>
