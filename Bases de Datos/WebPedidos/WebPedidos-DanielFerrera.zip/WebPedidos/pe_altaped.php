<?php
echo "Pagina para realizar pedido</br>";
echo "Numero de usuario y su contraseña <b>". $_COOKIE['usuario']."</b>";
 ?>
