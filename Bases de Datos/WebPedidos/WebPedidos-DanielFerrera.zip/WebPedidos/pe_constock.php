<?php
echo "Pagina para consultar stock de producto de una determinada línea de producto";
 ?>
