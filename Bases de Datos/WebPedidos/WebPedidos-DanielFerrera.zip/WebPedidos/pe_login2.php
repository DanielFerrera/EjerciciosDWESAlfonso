<!-- Código realizado por Daniel Ferrera -->
<!-- Pagina intermediaria, tanto si el usuario es correcto como si es incorrecto -->
<!-- Refresco: linea de codigo HTML para que actualiza la pagina cada 5s -->
<!-- <meta http-equiv="Refresh" content="7;url=pe_login2.php"> -->
<?php
//Llamada a fichero de funciones
include_once "funciones.php";

//Creamos la conexion a la base de datos
$servername="localhost"; $username="root"; $password="rootroot"; $dbname="pedidos";
$conexion=crearconexion($servername, $username, $password, $dbname);

//Funcionalidad: Si se escribe tanto el usuario como la contraseña
  if(isset($_POST['nombre']) && isset($_POST['contra'])){
    //Asignamos parámetros
    $nombre=$_POST['nombre'];
    $contra=$_POST['contra'];

    //Revision de parámetros
    revisarparametros($nombre,$contra);

    //Usuario=customernumber; contraseña=customerlastnumber;

    //Comprobamos los datos obtenidos con la base de datos para validar
    //Si es correcto se devuelve el valor de customername
    $customername=contra($nombre,$contra,$conexion);
    //Si los datos (usuario y contraseña) concuerdan con la base de datos
    //se inicia la sesión y se tiene acceso al menu de inicio
    if ($customername!="0") {
      echo "Has iniciado sesion: " . $_POST['nombre'] . "<br>";
      echo "Contraseña: " . $_POST['contra'] . "<br>";
      echo "Bienvenido: ".$customername. "<br>";
      echo "<p><a href='pe_inicio.html'>Menú de Inicio</a></p>";
      echo "<p><a href='pe_login.php'>Cerrar Sesion</a></p>";
      $cookie_name = "usuario";
      $cookie_value = "$nombre "."$contra";
      setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 segundos = 1 día
    }else {
      ?>
      <!-- Si se accede directamente a esta pagina se muestra el formulario para logear y error  -->
      <html>
      <head>
      	<title>Pagina Login Cookie</title>
      </head>
      <body>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
          <h1> Login Web Pedidos </h1>
      			<p>Usuario:<input type="text" placeholder="CustomerNumber" name="nombre" required/></p>
      			<p>Contraseña:<input type="text" placeholder="ContactLastName" name="contra" required/></p><br />
      			<input type="submit" value="Login" />
      		</form>
      </body>
      </html>
      <?php
      //Mensaje de error
      echo "Acceso Restringido debes hacer Login con tu usuario.";
      //Eliminacion de cookie si es que existe
        //setcookie("usuario", "", time() - 3600 , "/");
}
}else {
  echo "Acceso Restringido debes hacer Login con tu usuario.";

  ?>
  <!-- Se muestra en primera instacia al iniciar la pagina si no se introduce ni usuario ni contraseña -->
  <html>
  <head>
    <title>Pagina Login Cookie</title>
  </head>
  <body>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
      <h1> Login Web Pedidos </h1>
      <p>Usuario:<input type="text" placeholder="CustomerNumber" name="nombre" required/></p>
      <p>Contraseña:<input type="text" placeholder="ContactLastName" name="contra" required/></p><br />
      <input type="submit" value="Login" />
      </form>
  </body>
  </html>
  <?php
    }
  ?>
