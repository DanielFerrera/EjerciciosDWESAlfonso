<?php
echo "Pagina para consultar el pedido según el cliente";
 ?>
