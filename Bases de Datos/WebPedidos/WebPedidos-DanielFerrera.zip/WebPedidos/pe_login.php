<!-- Código realizado por Daniel Ferrera -->
<!-- Refresco: linea de codigo HTML para que actualiza la pagina cada 5s -->
<meta http-equiv="Refresh" content="7;url=pe_login.php">
<?php
//Borrado de todas las cookies: Al refrescarse la pagina cada 5s borra todas las cookies,
// principalmente para que al darle al botón de Cerrar Sesión desde pe_login2.php borre la cookie del usuario logeado
//Si lee que hay cookies, a través de un foreach las estabece a un tiempo anterior, por lo que se borran
if (isset($_SERVER['HTTP_COOKIE'])) {
    $cookies = explode(';', $_SERVER['HTTP_COOKIE']);
    foreach($cookies as $cookie) {
        $parts = explode('=', $cookie);
        $name = trim($parts[0]);
        setcookie($name, null, time()-3600);
        setcookie($name, null, time()-3600, '/');
    }
}
?>
<!-- Pagina de Login de la Web Pedidos -->
<html>
<head>
	<title>Pagina Login Cookie</title>
</head>
<body>
		<form action="pe_login2.php" method="POST">
			<h1> Login Web Pedidos </h1>
			<p>Usuario:<input type="text" placeholder="CustomerNumber" name="nombre" required/></p>
			<p>Contraseña:<input type="text" placeholder="ContactLastName" name="contra" required/></p><br />
			<input type="submit" value="Login" />
		</form>
</body>
</html>
